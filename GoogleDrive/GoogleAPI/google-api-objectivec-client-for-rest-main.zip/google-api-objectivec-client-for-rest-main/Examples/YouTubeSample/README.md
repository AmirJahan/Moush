# Example Project

## CocoaPods Dependencies

1. With Examples/YouTubeSample folder, run the following command to install
the required dependencies via CocoaPods.

```
$ pod install
```

2. Open the workspace:

```
$ open YouTubeSample.xcworkspace
```
